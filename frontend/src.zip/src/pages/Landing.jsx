import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import Features from "../components/Features";
import Footer from "../components/Footer";

import "../styles/landing.css";

const Landing = () => {

  return (

    <>

      <Navbar />

      <Hero />

      <Features />

      <Footer />

    </>

  );

};

export default Landing;