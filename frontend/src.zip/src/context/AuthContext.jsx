import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {

    const [user, setUser] = useState(
        JSON.parse(localStorage.getItem("user"))
    );

    const login = (token, userData) => {

        localStorage.setItem("token", token);
        localStorage.setItem(
            "user",
            JSON.stringify(userData)
        );

        setUser(userData);
    };

   const logout = () => {

    localStorage.removeItem("token");

    localStorage.removeItem("user");

    setUser(null);

    window.location.href = "/login";

};

    return (

        <AuthContext.Provider
            value={{
                user,
                login,
                logout,
                isAdmin: user?.role === "admin"
            }}
        >

            {children}

        </AuthContext.Provider>

    );

};



export const useAuth = () => useContext(AuthContext);